import React, { useState } from "react";

const products = [
  { id: 1, name: "粉色玫瑰花束", price: 25 },
  { id: 2, name: "向日葵花束", price: 20 },
  { id: 3, name: "满天星花束", price: 18 },
];

const languages = {
  zh: {
    title: "手工花店",
    cart: "购物车",
    contact: "联系客服",
    addToCart: "加入购物车",
    goToWhatsapp: "通过 WhatsApp 联系",
  },
  en: {
    title: "Handmade Flower Shop",
    cart: "Cart",
    contact: "Contact Us",
    addToCart: "Add to Cart",
    goToWhatsapp: "Contact via WhatsApp",
  },
  id: {
    title: "Toko Bunga Handmade",
    cart: "Keranjang",
    contact: "Hubungi Kami",
    addToCart: "Tambah ke Keranjang",
    goToWhatsapp: "Hubungi lewat WhatsApp",
  },
};

export default function FlowerShop() {
  const [cart, setCart] = useState([]);
  const [lang, setLang] = useState("zh");
  const t = languages[lang];

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  const whatsappMessage = encodeURIComponent(
    `你好，我想购买：\n` +
      cart.map((item) => `- ${item.name} (${item.price} USD)`).join("\n") +
      `\n总价：${cart.reduce((sum, item) => sum + item.price, 0)} USD`
  );

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 20 }}>
        <h1>{t.title}</h1>
        <select value={lang} onChange={(e) => setLang(e.target.value)}>
          <option value="zh">中文</option>
          <option value="en">English</option>
          <option value="id">Bahasa</option>
        </select>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
        {products.map((product) => (
          <div key={product.id} style={{ border: "1px solid #ccc", borderRadius: 12, padding: 12 }}>
            <h3>{product.name}</h3>
            <p>${product.price}</p>
            <button onClick={() => addToCart(product)}>{t.addToCart}</button>
          </div>
        ))}
      </div>

      <div style={{ marginTop: 30 }}>
        <h2>{t.cart}</h2>
        {cart.length === 0 ? (
          <p>购物车是空的</p>
        ) : (
          <ul>
            {cart.map((item, index) => (
              <li key={index}>{item.name} - ${item.price}</li>
            ))}
          </ul>
        )}

        <a
          href={`https://wa.me/1234567890?text=${whatsappMessage}`}
          target="_blank"
          rel="noopener noreferrer"
        >
          <button style={{ marginTop: 12 }}>{t.goToWhatsapp}</button>
        </a>
      </div>
    </div>
  );
}
