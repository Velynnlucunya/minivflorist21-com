import React from 'react'
import ReactDOM from 'react-dom/client'
import FlowerShop from './FlowerShop'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <FlowerShop />
  </React.StrictMode>
)